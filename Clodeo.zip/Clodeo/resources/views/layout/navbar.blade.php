<style>
    nav ul .navbar {
        float: right;
        list-style: none;
        padding-right: 0px;
        height: 60px;
    }

    nav ul .navbar .logonavbar {
        height: 40px;
        width: 40px;
    }
</style>

<nav>
    <div class="container">
        <div class="row">
            <div class="col-12">
                <ul>
                    <li class="navbar">Hi, Admin<img class="logonavbar" src="{{ ('/image/logo.png') }}" style="margin-left: 16px"></li>
                </ul>
            </div>
        </div>
    </div>
</nav>